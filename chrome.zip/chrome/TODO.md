[ ] https://stackoverflow.com/questions/14149209/read-the-version-from-manifest-json: chrome.runtime.getManifest().version and ask to reload on new version
[ ] https://developer.chrome.com/extensions/contextMenus
[ ] https://github.com/brainbreaker/clearData-WebExtension-Demo
[ ] https://github.com/bytepicker/Thrasher
[ ] https://developer.chrome.com/extensions/management#method-getself
[ ] https://stackoverflow.com/questions/8960193/how-to-make-html-element-resizable-using-pure-javascript
[ ] Simple Pure CSS Drop Down Menu: https://codepen.io/philhoyt/pen/ujHzd
[ ] Preview image: http://cssglobe.com/lab/tooltip/02/